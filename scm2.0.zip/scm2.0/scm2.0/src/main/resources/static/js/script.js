console.log("script loaded");

let currentTheme=getTheme();

document.addEventListener("DOMContentLoaded", () => {
    changeTheme();
});

// Todo
function changeTheme(){
    //set to web page
    changePageTheme(currentTheme,"");

    // set the listener to changetheme
    const changeThemeButton = document.querySelector('#theme_change_button')
   
    
     
    changeThemeButton.addEventListener("click",(event)=> {
        let oldTheme =currentTheme;
        console.log("change theme button clicked");
        if(currentTheme == "dark"){
            currentTheme="Light" ;
        }else{
            currentTheme="dark";
        }
        console.log(currentTheme);
        changePageTheme(currentTheme, oldTheme);
        
    });

    
}
// set theme to local storage
function setTheme(theme) {
    const oldTheme = currentTheme;
    localStorage.setItem("theme", theme);
}

// get theme from local storage
function getTheme(){
    let theme = localStorage.getItem("theme");
    return theme ? theme : "Light";
}


function changePageTheme(theme,oldTheme){
    setTheme(currentTheme);
    if(oldTheme){
        document.querySelector('html').classList.remove(oldTheme);
    }

    document.querySelector('html').classList.add(theme);

    document
    .querySelector('#theme_change_button')
    .querySelector('span').textContent = theme == "Light" ? "Dark" : "Light";


}
