package com.scm.entities;

public enum Providers {

    SELF, GOOGLE, GITHUB

}
