package com.scm.helpers;

public enum MessageType {

    blue, green, red, yellow

}
