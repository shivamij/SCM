package com.scm.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.scm.entities.User;
import com.scm.forms.UserForm;
import com.scm.helpers.Message;
import com.scm.helpers.MessageType;
import com.scm.services.UserService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;


@Controller

public class pagecontroller {

    @Autowired
    private UserService userService;

    @GetMapping("/")
    public String index(){
        return "redirect:/home";
    }

    

    @RequestMapping("/home")
    public String home(Model model)
    {
        System.out.println("home page handler");
        model.addAttribute("name", "substring technologies");
        model.addAttribute("youtubechannel", "south park");
        model.addAttribute("githubrepository", "https://github.com/shivamij/Amazon-web-clone/tree/main");
        return "home";

    }
 
    // about route
    @RequestMapping("/about")
    public String aboutPage(Model model){
        model.addAttribute("isLogin", true);
        System.out.println("about page loading");
        return "about";
    }

    // services route
    @RequestMapping("/services")
    public String servicePage(){
        System.out.println("service page loading");
        return "services";
    }

    // contacts page
    @GetMapping("/contact")
    public String contact() {
        return new String("contact");
    }

    // login page
    @GetMapping("/login")
    public String login() {
        return new String("login");
    }

    // register page
    @GetMapping("/register")
    public String register(Model model) {

        UserForm userForm = new UserForm();
        //userForm.setName("shivam");
        //userForm.setAbout("hello");
        model.addAttribute("userForm", userForm);
        return "register";
    }

    // processing register
    @RequestMapping(value = "/do-register", method = RequestMethod.POST)
    public String processRegister(@Valid @ModelAttribute UserForm userForm, BindingResult rBindingResult, HttpSession session){
        System.out.println("processing registration");
        // fetch form data
        //Userform
        System.out.println(userForm);

        //validate from data
        if(rBindingResult.hasErrors()){
            return "register";
        }
        //save to database

        //userservice

        // User user=User.builder()
        // .name(userForm.getName())
        // .email(userForm.getEmail())
        // .password(userForm.getPassword())
        // .about(userForm.getAbout())
        // .phoneNumber(userForm.getPhoneNumber())
        // .profilePic("https://static-00.iconduck.com/assets.00/profile-default-icon-2048x2045-u3j7s5nj.png")
        // .build();

        User user = new User();
        user.setName(userForm.getName());
        user.setEmail(userForm.getEmail());
        user.setPassword(userForm.getPassword());
        user.setAbout(userForm.getAbout());
        user.setPhoneNumber(userForm.getPhoneNumber());
        user.setEnabled(false);
        user.setProfilePic("https://static-00.iconduck.com/assets.00/profile-default-icon-2048x2045-u3j7s5nj.png");



        User savedUser = userService.saveUser(user);
        System.out.println("user saved :");
        
        //message = " registration successful"
        
        // add the message
        Message message = Message.builder().content("Registration Successful").type(MessageType.blue).build();
        
        session.setAttribute("message",message);

        // redirect to login page
        return "redirect:/register";
    }
    
    
    


}
