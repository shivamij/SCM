import { selector } from 'postcss-selector-parser';

/** @type {import('tailwindcss').Config} */
export default {
  content: ["./scm2.0/src/main/resources/**/*.{html,js}"],
  theme: {
    extend: {},
  },
  plugins: [],
  corePlugins: {
    // Ensure text-size-adjust is not disabled if you need it
    textSizeAdjust: false,
    webkittextsizeadjust: false,
    textOpacity: false,
  },
  darkMode: "selector",
};

